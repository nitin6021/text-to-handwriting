Road Map
========

The following functions are still unimplemented as of version 0.0.2:

* `collideAny(self, rectsOrPoints)`
* `collideAll(self, rectsOrPoints)`
